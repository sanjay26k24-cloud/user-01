---
name: commit-progression-changelog-builder
description: Analyzes staged git changes and the latest Keylogger log file, prompts the user for a commit message, commits the staged changes, prepends a definitive progression section (with old commit hash, old changelog commit hash, new commit hash, IST timestamp, a 3-4 line progression summary, and a 2-3 line Keylogger Report) to CHANGELOG.md, creates a separate commit for CHANGELOG.md, and automatically pushes both commits to GitHub (https://github.com/SOCS-Elite-WR-2027/24BCT044.git). Use this skill whenever the user wants to commit changes with a progression changelog and keylogger report, update CHANGELOG.md from staged changes, or invoke commit-progression-changelog-builder.
---

# Commit Progression Changelog Builder

This skill manages a two-commit Git progression, keylogger comparison report, and automatic GitHub push workflow. Every run produces:
1. **The primary commit (`<new_commit>`)** containing the user's staged files, using the commit message provided by the user.
2. **A separate, automatic changelog commit (`<new_changelog_commit>`)** containing the updated `CHANGELOG.md` with the prepended 3–4 line Progression Summary and 2–3 line Keylogger Report.
3. **An automatic push to GitHub** (`https://github.com/SOCS-Elite-WR-2027/24BCT044.git`) so the code, progression changelog, and keylogger report are immediately synced to the remote repository.

This guarantees a clean linear commit chain across runs:
`<old_commit_a> --> <old_changelog_commit_a> --> <new_commit> --> <new_changelog_commit>`

---

## Workflow Overview

Execute the steps below strictly in order. Do not skip the gate check or the user commit-message prompt, always create the separate `CHANGELOG.md` commit automatically after updating the changelog, and push the commits and keylogger report to GitHub.

```mermaid
flowchart TD
    A["Start Workflow"] --> B{"Any files staged in Git?"}
    B -- "No" --> B1["Prompt user to stage changes first & STOP"]
    B -- "Yes" --> D["Resolve <old_commit_a> & <old_changelog_commit_a>, analyze staged diff & latest Keylogger .log"]
    D --> E["Prompt user for primary commit message (Non-Negotiable) & WAIT"]
    E --> F["Commit staged files as <new_commit> & capture NEW_HASH + IST timestamp"]
    F --> G["Prepend 3-4 line Progression Summary & 2-3 line Keylogger Report to CHANGELOG.md"]
    G --> H["Automatically stage & commit CHANGELOG.md as separate <new_changelog_commit>"]
    H --> I["Automatically push code & CHANGELOG.md (with Keylogger Report) to GitHub"]
```

---

## Step-by-Step Instructions

### Step 1: Pre-Flight Gate Check (Staged Files)

Before analyzing diffs or asking for a commit message, verify the Git staging area from the repository root:

```bash
git diff --cached --name-only
```

1. **Check if anything is staged**:
   - If the output of `git diff --cached --name-only` is empty, **stop immediately**.
   - Prompt the user: *"No changes are currently staged. Please stage your files using `git add` before running this workflow."*
   - Do **not** stage files on the user's behalf unless they explicitly instruct you which files to stage.

---

### Step 2: Resolve Previous Commit Hashes & Analyze Staged Changes

Because this skill creates a separate automatic changelog commit after every primary commit, the Git history before your new commit looks like:
`<old_commit_a> --> <old_changelog_commit_a>`

1. **Resolve `<old_commit_a>` and `<old_changelog_commit_a>` before committing**:
   - If no commits exist yet in the repository (`git rev-parse --verify HEAD` fails):
     - `OLD_COMMIT_HASH` = `None (Initial Commit)`
     - `OLD_CHANGELOG_HASH` = `None`
   - If `HEAD` was an automatic changelog commit (i.e. its subject starts with `docs(changelog):` or `chore(changelog):`, or `git diff-tree --no-commit-id --name-only -r HEAD` is only `CHANGELOG.md`) and `HEAD~1` exists:
     - `OLD_COMMIT_HASH` (`<old_commit_a>`) = `git rev-parse --short=7 HEAD~1`
     - `OLD_CHANGELOG_HASH` (`<old_changelog_commit_a>`) = `git rev-parse --short=7 HEAD`
   - Otherwise (if `HEAD` was a normal commit without a follow-up changelog commit):
     - `OLD_COMMIT_HASH` (`<old_commit_a>`) = `git rev-parse --short=7 HEAD`
     - `OLD_CHANGELOG_HASH` = `None`

2. **Analyze all staged changes & latest Keylogger log**:
   - Run `git diff --cached --stat` and `git diff --cached` to inspect every staged file in detail.
   - Review `CHANGELOG.md` (if present) or recent commits (`git log -n 4 --oneline`) to understand the baseline state at `<old_commit_a>`.
   - Inspect the most recently created/modified `.log` file inside `/home/sanjay/Desktop/sanjay/brain-storming/new-skill/setup/Keylogger/linux` (`ls -t /home/sanjay/Desktop/sanjay/brain-storming/new-skill/setup/Keylogger/linux/*.log | head -n 1`), reconstruct the recorded keystrokes/commands (accounting for `\x08` backspaces and `\r` line breaks), and compare the recorded session actions against the staged Git diff.
   - Synthesize how the project has **progressed** from `<old_commit_a>` to the newly staged state (new features, architectural changes, bug fixes, and test coverage) along with the keylogger comparison report.

---

### Step 3: Prompt the User for the Commit Message (Non-Negotiable)

**You must always prompt the user for the primary commit message before creating `<new_commit>`.** Even if the user's initial request included a rough description of their changes, stop and ask them to provide or confirm the exact commit message they want to use.

When prompting the user:
- Briefly list the staged files.
- Ask: *"What commit message would you like to use for this commit?"*
- Wait for the user's response before proceeding to Step 4.
- *(Note: You only prompt the user once for the primary commit message. The subsequent `CHANGELOG.md` commit in Step 6 is done automatically without prompting again.)*

---

### Step 4: Create Primary Commit (`<new_commit>`) & Capture Metadata

After the user replies with their commit message:

1. **Ensure `CHANGELOG.md` is not mixed into the primary commit**:
   If `CHANGELOG.md` happened to be staged manually, unstage it first (`git reset HEAD CHANGELOG.md 2>/dev/null || true`) so that `<new_commit>` contains the project changes and `<new_changelog_commit>` remains a distinct commit.

2. **Create `<new_commit>`**:
   ```bash
   git commit -m "<user_commit_message>"
   ```

3. **Capture the new 7-character commit hash (`NEW_HASH` / `<new_commit>`)**:
   ```bash
   git rev-parse --short=7 HEAD
   ```

4. **Capture the current timestamp in Indian Standard Time (`IST`, `UTC+05:30`)**:
   ```bash
   TZ="Asia/Kolkata" date "+%Y-%m-%d %H:%M:%S IST"
   ```

---

### Step 5: Prepend Progression Section to `CHANGELOG.md`

Maintain a central `CHANGELOG.md` file in the root of the Git repository.
- If `CHANGELOG.md` does not exist, create it with `# Changelog` as the top-level heading.
- If `CHANGELOG.md` already exists, **prepend** the new commit section immediately below the `# Changelog` header block, so the **most recent commit summary is always at the top** of the changelog.

#### Definitive `CHANGELOG.md` Format

When a previous changelog commit exists, format the progression chain as `<old_commit_a> --> <old_changelog_commit_a> --> <new_commit>`:

```markdown
# Changelog

All notable commit-by-commit progressions for this project are documented in this file (most recent first).

---

## [<new_commit>] - <YYYY-MM-DD HH:MM:SS IST>

- **Progression**: `<old_commit_a>` --> `<old_changelog_commit_a>` --> `<new_commit>`
- **Old Commit Hash**: `<old_commit_a>` (changelog commit: `<old_changelog_commit_a>`)
- **New Commit Hash**: `<new_commit>`
- **Timestamp (IST)**: `<YYYY-MM-DD HH:MM:SS IST>`
- **Commit Message**: `<user_commit_message>`

### Progression Summary
<Line 1: Simple overview of progression from <old_commit_a> to <new_commit>.>
<Line 2: Main files or features added/updated in this commit.>
<Line 3: Key structure or configuration changes included.>
<Line 4 (Optional): Current state after this commit.>

### Keylogger Report
<Line 1: Latest keylog file name in Keylogger/linux/ compared against the committed files.>
<Line 2: Simple summary of how the recorded keystrokes/commands match the file edits and Git actions.>
<Line 3 (Optional): Final verification note (strictly 2 to 3 lines max).>

---
```

*(If no prior changelog commit exists—for example, on the first commit or after a manual commit—omit `--> <old_changelog_commit_a>` so the progression reads `` `<old_commit_a>` --> `<new_commit>` ``.)*

#### Summary & Keylogger Report Writing Rules
- **Progression Summary (3–4 Simple Lines Max)**: The `### Progression Summary` body must be **3 to 4 simple, easy-to-read lines maximum** (never exceed 4 lines).
- **Keylogger Report (2–3 Simple Lines Max)**: The `### Keylogger Report` body must be **2 to 3 simple lines maximum** (never exceed 3 lines) comparing the latest `.log` file in `/home/sanjay/Desktop/sanjay/brain-storming/new-skill/setup/Keylogger/linux` with the committed changes.
- **Focus on Clarity**: Keep both sections concise and written in plain, simple language.

#### Bundled Helper Script
Use the bundled script [`scripts/update_changelog.py`](scripts/update_changelog.py) to deterministically resolve the commit chain (`<old_commit_a> --> <old_changelog_commit_a> --> <new_commit>`), validate the 3–4 line summary limit and 2–3 line Keylogger Report limit, prepend the entry to `CHANGELOG.md`, auto-commit `CHANGELOG.md`, and auto-push to GitHub:

```bash
python3 <path-to-skill>/scripts/update_changelog.py \
  --changelog CHANGELOG.md \
  --old-hash "<old_commit_a>" \
  --old-changelog-hash "<old_changelog_commit_a>" \
  --new-hash "<new_commit>" \
  --timestamp "<YYYY-MM-DD HH:MM:SS IST>" \
  --message "<user_commit_message>" \
  --summary "<3-4 line summary text>" \
  --keylog-dir "/home/sanjay/Desktop/sanjay/brain-storming/new-skill/setup/Keylogger/linux" \
  --keylog-comparison "<2-3 line keylogger comparison summary>" \
  --auto-commit \
  --auto-push
```

Or let the script inspect Git history and the latest keylog file automatically right after `<new_commit>` is created:

```bash
python3 <path-to-skill>/scripts/update_changelog.py \
  --changelog CHANGELOG.md \
  --from-git \
  --summary "<3-4 line summary text>" \
  --keylog-comparison "<2-3 line keylogger comparison summary>" \
  --auto-commit \
  --auto-push
```

---

### Step 6: Automatically Create Separate Changelog Commit (`<new_changelog_commit>`)

Immediately after updating `CHANGELOG.md` in Step 5, **automatically stage and commit `CHANGELOG.md` as a separate commit** (if you did not already pass `--auto-commit` to `update_changelog.py`):

```bash
git add CHANGELOG.md
git commit -m "docs(changelog): record progression for <new_commit>"
```

Verify with `git log -n 4 --oneline` that the commit history follows the exact progression:
`<old_commit_a> --> <old_changelog_commit_a> --> <new_commit> --> <new_changelog_commit>`

---

### Step 7: Automatically Push Code & Keylogger Report to GitHub

Immediately after `<new_changelog_commit>` is created, ensure the GitHub remote (`https://github.com/SOCS-Elite-WR-2027/24BCT044.git`) is configured and push the active branch (if you did not already pass `--auto-push` to `update_changelog.py`):

```bash
git remote get-url origin >/dev/null 2>&1 || git remote add origin https://github.com/SOCS-Elite-WR-2027/24BCT044.git
git push -u origin HEAD
```

Finally, report the new commit hash, the automatic changelog commit hash, the GitHub push status, and the prepended `CHANGELOG.md` section (including both the `Progression Summary` and `Keylogger Report`) to the user.
