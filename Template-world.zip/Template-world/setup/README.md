# Project setup notes

This guide describes the project layout, environment troubleshooting, agent setup, and a changelog format. It intentionally does not provide instructions for installing or running software that captures keystrokes across the system.

## Project layout

- `Keylogger/` contains the platform-specific source and documentation.
- `demoenv/` is present in this project, but virtual environments are machine-specific and should not be copied or moved between projects.
- `.agents/skills/` contains the project's agent skill files.

The terminal transcript in the issue used `Keylogger/linux`, while the Linux files in the current project tree are under `setup/Keylogger/linux`. Check your current directory and the actual project layout before using a path:

```text
pwd
ls
ls setup/Keylogger
```

`Keyogger` is a typo; the directory is named `Keylogger`. The path `demoenvbin/activate` is also missing a slash between `demoenv` and `bin`.

## Python environment note

The transcript's `which python` output points to `/home/sanjay/Desktop/SAMPLE-KEY/demoenv/bin/python`. That is not the environment under this project. A prompt showing `(demoenv)` is not enough to confirm which interpreter is active; inspect the interpreter path and use a fresh, project-local environment for benign development work. Do not copy or move an existing virtual environment.

## Agent setup

No extra agent setup command is needed just to read or edit this project. The skill files are stored under `.agents/skills/`. In VS Code, open the project folder and use the Copilot Chat agent normally. If a skill does not appear, confirm that its `SKILL.md` is in the supported workspace skill location and has valid frontmatter.

## Changelog format

Use `CHANGELOG.md` to record software changes by release or under an `Unreleased` heading. Do not use it as a keystroke or activity log.

```markdown
# Changelog

## [Unreleased]

### Added
- Describe a user-visible addition.

### Changed
- Describe a behavior or documentation change.

### Fixed
- Describe a corrected issue.
```

Keep entries brief and factual. Add a dated version heading when preparing a release, for example `## [1.0.0] - YYYY-MM-DD`.

## Platform-specific note

The Windows and Linux folders contain keylogger source. Because system-wide key capture can expose passwords and private information, this guide does not include commands for running those files. For keyboard-input learning, use a visible application that reads only from its own text field.
